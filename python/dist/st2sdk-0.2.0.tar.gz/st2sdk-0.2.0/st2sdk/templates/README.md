# {{ pack_name|title }} Integration Pack

[Short description of what the pack does]

## Configuration

[Description of the configuration options]

## Sensors

[Description of all the available sensors]

## Actions

[Description of all the available actions]
